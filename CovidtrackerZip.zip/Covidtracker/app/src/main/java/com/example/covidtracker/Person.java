package com.example.covidtracker;

import java.util.Date;

//@RequiresApi(api = Build.VERSION_CODES.O)
public class Person {

    public String name;
    public int age;
    public String contact;
//    public DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
    public Date dataInfectarii;

    public Person() {
        // Default constructor required for calls to DataSnapshot.getValue(User.class)
    }

    public Person(String name, int age, String contact, Date data) {
        this.name = name;
        this.age = age;
        this.contact = contact;
        this.dataInfectarii = data;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public int getAge() {
        return age;
    }

    public String getContact() {
        return contact;
    }

    public Date getDataInfectarii() {
        return dataInfectarii;
    }

    public void setDataInfectarii(Date dataInfectarii) {
        this.dataInfectarii = dataInfectarii;
    }

    public String toString(){
        return "Nume: " + name + ", \nVarsta: " + age + ", \nContact direct: " + contact;
    }

}

