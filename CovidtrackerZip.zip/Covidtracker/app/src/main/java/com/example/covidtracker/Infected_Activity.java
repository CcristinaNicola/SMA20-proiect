package com.example.covidtracker;

import androidx.annotation.MainThread;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;


//@RequiresApi(api = Build.VERSION_CODES.O)
public class Infected_Activity extends AppCompatActivity {

    private EditText nameTxt, ageTxt, contactTxt;
    private Spinner sp;
    private DatabaseReference databaseReference;

//    public DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
    private Button confirm;
    FirebaseHelper firebaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.infected_layout);

        //SETUP DB
        databaseReference = FirebaseDatabase.getInstance().getReference("Person");
        firebaseHelper = new FirebaseHelper(databaseReference);

        nameTxt = (EditText) findViewById(R.id.name);
        ageTxt = (EditText) findViewById(R.id.age);
        contactTxt = (EditText) findViewById(R.id.contact);

        confirm = (Button) findViewById(R.id.confirm);
        sp = findViewById(R.id.sp);

        //SAVE
        confirm.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(View v) {
                //GET DATA
                String name = nameTxt.getText().toString();
                int age = Integer.parseInt(ageTxt.getText().toString());
                String contact = contactTxt.getText().toString();

                //SET DATA
//                SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
                Person p = new Person(name, age, contact, new Date());
                //SAVE
                if (name != null && name.length() > 0 && age != 0 && contact != null && contact.length() > 0 ) {
                    if (firebaseHelper.save(p)) {
                        nameTxt.setText("");
                        ageTxt.setText("");
                        contactTxt.setText("");
                    }

                } else {
                    Toast.makeText(Infected_Activity.this, "Cannot be empty", Toast.LENGTH_SHORT).show();
                }

            }
        });

//        ArrayAdapter arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, firebaseHelper.retrieve());
//        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
//        sp.setAdapter(arrayAdapter);

    }
}