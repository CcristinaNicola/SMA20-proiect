package com.example.covidtracker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;

public class Search_Activity extends AppCompatActivity {

    private EditText mSearchField;
    private Button mSearchBtn;
    private ListView mResultList;
    private DatabaseReference databaseReference;
    private ArrayList<Person> persons = new ArrayList<>();
    private PersonAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_layout);

        mSearchBtn = findViewById(R.id.searchBtn);
        mSearchField = findViewById(R.id.search_box);
        mResultList = findViewById(R.id.search_result);
        databaseReference = FirebaseDatabase.getInstance().getReference("Person");

        adapter = new PersonAdapter(Search_Activity.this, persons);
        mResultList.setAdapter(adapter);

        mSearchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                searchForTheItem();
            }

        });
    }

    public void searchForTheItem(){
        Query query = databaseReference.orderByKey();

        ValueEventListener queryValueListener = new ValueEventListener() {

            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                Iterable<DataSnapshot> snapshotIterator = dataSnapshot.getChildren();
                Iterator<DataSnapshot> iterator = snapshotIterator.iterator();

                while (iterator.hasNext()) {
                    DataSnapshot next = (DataSnapshot) iterator.next();
                    Person p = next.getValue(Person.class);
                    String numeCautat = mSearchField.getText().toString();

                    if (mSearchField.getText().toString().equals(p.getName())) {
                        SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
                        persons.add(p);
                        adapter.notifyDataSetChanged();
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        };

        query.addListenerForSingleValueEvent(queryValueListener);
    }
}

class PersonAdapter extends BaseAdapter{
    ArrayList<Person> persons;
    Context context;
    LayoutInflater inflater;

    public PersonAdapter(Context context, ArrayList<Person> persons) {
        // TODO Auto-generated constructor stub
        this.context = context;
        inflater = LayoutInflater.from(context);
        this.persons = persons;
    }

    @Override
    public int getCount() {
        return persons.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewGroup vg;

        if (convertView != null) {
            vg = (ViewGroup) convertView;
        } else {
            vg = (ViewGroup) inflater.inflate(R.layout.row, null);
        }

        Person p = persons.get(position);
        TextView name = vg.findViewById(R.id.textName);
        TextView age = vg.findViewById(R.id.textAge);
        TextView contact = vg.findViewById(R.id.textContact);
        TextView data = vg.findViewById(R.id.textDate);

        name.setText(p.getName());
        age.setText(String.valueOf(p.getAge()));
        contact.setText(p.getContact());
        SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
        data.setText(formatter.format(p.getDataInfectarii()));

        return vg;
    }
}

